document.write(+number("3.1493002893"));
document.write(+number("  "));
document.write(+number(""));
document.write(+number("98" "88"));

let num=100;
let n=25;
let s=string("100+23");
document.write("</br>"+string(num));
document.write("</br>"+string());
